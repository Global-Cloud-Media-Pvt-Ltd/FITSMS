package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
)

type SMSRequest struct {
	Recipient string `json:"recipient"`
	Message   string `json:"message"`
	Type      string `json:"type"`
	SenderID  string `json:"sender_id"`
}

const (
	apiURL   = "https://app.fitsms.lk/api/v3/sms/send"
	apiKey   = "156|sdZH6VMVFshMVCKv5dQ15HaEbXen1JTjKQcwmOvA "
	senderID = "Global CM"
)

func sendSMS(to string, message string) {
	client := &http.Client{}

	payload := SMSRequest{
		Recipient: to,
		Message:   message,
		Type:      "plain",
		SenderID:  senderID,
	}

	jsonData, err := json.Marshal(payload)
	if err != nil {
		fmt.Println("Error encoding JSON:", err)
		return
	}

	req, err := http.NewRequest("POST", apiURL, bytes.NewBuffer(jsonData))
	if err != nil {
		fmt.Println("Error creating request:", err)
		return
	}

	req.Header.Set("Authorization", "Bearer "+apiKey)
	req.Header.Set("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		fmt.Println("Error sending request:", err)
		return
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		fmt.Println("Error reading response:", err)
		return
	}

	fmt.Println("Response:", string(body))
}

func main() {
	// Replace with actual phone number including country code
	sendSMS("+94761695904", "Test Message from Go!")
}
